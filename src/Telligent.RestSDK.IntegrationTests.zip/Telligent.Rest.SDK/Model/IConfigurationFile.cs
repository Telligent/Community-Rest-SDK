namespace Telligent.Rest.SDK.Model
{
    public interface IConfigurationFile
    {
        string GetConfigurationData();
    }
}
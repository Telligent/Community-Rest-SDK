﻿using System.Collections.Generic;
using System.Dynamic;
using System.Threading.Tasks;
using Telligent.Evolution.RestSDK.Json;
using Telligent.Evolution.RestSDK.Services;

namespace Telligent.Evolution.RestSDK.Implementations
{
    public class Deserializer : IDeserializer
    {
        public async Task Deserialize(dynamic element, JsonReader reader)
        {
            while (await reader.Read())
            {
                switch (reader.Type)
                {
                    case JsonObject.JsonType.Object:
                        await AddObject(element, reader);
                        break;
                    case JsonObject.JsonType.Array:
                        await AddArray(element, reader);
                        break;
                    default:
                        await AddProperty(element, reader.Value, reader.Property);
                        break;
                }
            }
        }

        private async Task AddArray(dynamic element, JsonReader reader)
        {
            var dynamicList = new List<dynamic>();
            var list = reader.Value as IEnumerable<string>;

            if (list == null) return;

            foreach (var item in list)
            {
                dynamic arrayElement = new ExpandoObject();

                var itemChars = item.ToCharArray();
                var itemType = JsonObject.GetTypeFromValue(item);

                switch (itemType)
                {
                    case JsonObject.JsonType.String:
                        await AddProperty(arrayElement, JsonParser.ReadAsString(itemChars), reader.Property);
                        break;
                    case JsonObject.JsonType.Number:
                       await AddProperty(arrayElement, JsonParser.ReadAsNumber(itemChars), reader.Property);
                        break;
                    case JsonObject.JsonType.Boolean:
                       await AddProperty(arrayElement, JsonParser.ReadAsBoolean(itemChars), reader.Property);
                        break;
                    case JsonObject.JsonType.Object:
                      await  Deserialize(arrayElement, new JsonReader(item));
                        break;
                    case JsonObject.JsonType.Array:
                       await AddArray(arrayElement, new JsonReader(item)
                        {
                            Property = reader.Property,
                            Value = JsonParser.ReadAsArray(itemChars),
                            Text = item,
                            Type = JsonObject.JsonType.Array
                        });
                        break;
                }

               await AddProperty(dynamicList, arrayElement);
            }

           await AddProperty(element, dynamicList, reader.Property);
        }

        private async Task AddObject(dynamic element, JsonReader reader)
        {
            dynamic dynamicElement = new ExpandoObject();

           await  Deserialize(dynamicElement, new JsonReader(reader.Value.ToString()));

           await AddProperty(element, dynamicElement, reader.Property);
        }

        private async Task AddProperty(dynamic element, object value, string name = null)
        {
            if (element is List<dynamic>)
            {
                (element as List<dynamic>).Add(value);
            }
            else
            {
                var dictionary = element as IDictionary<string, object>;
                if (dictionary != null) dictionary[name ?? "_"] = value;
            }
        }
    }
}

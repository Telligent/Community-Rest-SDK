﻿using System.Threading.Tasks;
using Telligent.Evolution.RestSDK.Json;

namespace Telligent.Evolution.RestSDK.Services
{
    public interface IDeserializer
    {
        Task Deserialize(dynamic element, JsonReader reader);
    }
}
